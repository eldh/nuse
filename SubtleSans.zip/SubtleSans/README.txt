
Subtle Sans is made by Atle Mo.
You can use this font in any way you like, both commercial and noncommercial. No attribution required.

The latest version of the font will always be at:
http://www.subtlepatterns.com/subtlesans/

ENJOY!